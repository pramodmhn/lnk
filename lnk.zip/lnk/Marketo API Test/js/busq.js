
        $("#token").val(token);  
        var fields;//array of fields to return
        var  button_no = 0;
        var max_limit,min_limit;
        
        $("#displayData").hide();
        $("#displayMatchData").hide();


        $("#getToken").click(function(){            
            getToken();            
        });
        $("#getData").click(function(){         
            getLeadsById();
        });
        
        //merge by 20 records
        $(".btn-merge-20").click(function(){
//            location.reload();
            $(this).css("background-color","#00ff00");
            button_no = $(this).text();
            min_limit = $(this).attr("data-min");
            max_limit = $(this).attr("data-max");
            getLeadsLists(totalArray.slice(min_limit,max_limit)); 
        })
        

        //merge button click
        $(document).on("click",".scheduler-border .merge-field",function(){  
            $(this).hide();
            var wining_id = $(this).prev().find(".winning-id").val();
            var losing_id = $(this).prev().find(".losing-id").val();
            var result =  $(this).next().removeClass("d-none").find(".merge-result");
//            console.log(wining_id + ": " +losing_id);
            mergeField(wining_id,losing_id,result);
        });
        
            // Merge All
            $(".btn-mergeAll").click(function(){
                $(".merge-field").each(function(i,e){
                    if(i<25){
                        $(this).trigger("click");
                    }
                       
                })
            })
            
             $(".btn-mergeAll-50").click(function(){
                $(".merge-field").each(function(i,e){
                    if(i>=25){
                        $(this).trigger("click");
                    }
                       
                })
            })
            
       function getToken(){ 
          $.ajax({
                method: "GET",
              crossDomain: true,
                url: host + "/identity/oauth/token",                  
                data: { grant_type: "client_credentials", client_id: clientId,client_secret:clientSecret },
                dataType: "json",
                success: function (result) {
                   var token = result.access_token;
                    $("#token").val(token);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    console.log(xhr);
                }
            });                
        }
        
        
        function getLeadsById(){
            var acc_token = $("#token").val();  
             console.log("host"+host);
             var id = $("#marketoId").val();//id of lead to return 1647343
            $.ajax({
                method: "GET",                
                url: host + "/rest/v1/lead/" + id + ".json",                  
                data: { access_token: acc_token, fields: "email,planMemberRef" },
                dataType: "json",
                success: function (data) {                    
                    console.log(data.result);
                    var results = data.result[0];
                    var final_data = "";
                    $.each(results,function(i,e){
                        console.log(e);
                        final_data += i + ": " +e +"<br>";
                    });
                    $("#displayDataById").html(final_data);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    console.log(xhr);
                }
            });     
        }
        
        //https://855-bwk-979.mktorest.com/rest/v1/leads.json?filterType=email&filterValues=aaanderr@hotmail.com&fields=id,firstname,lastname,email,planMemberRef,planEmployerRef&access_token=a175cc25-c3d1-46a9-8782-e390a3af27ad:sn
        function getLeadsLists(array20s){
            $("fieldset.scheduler-border").html('<legend class="scheduler-border">Merge Data:'+button_no+'</legend>');
            var newArray = [];
            var acc_token = $("#token").val();  
            var email = $("#marketoEmail").val();
            var emailArr = array20s;
            //$("#marketoEmail").val().split('\n');//["zzuka@teamedge.org","yini.zhao@peto.com.au"];zsolomons@casemeallin.com.au yini.zhao@peto.com.au woodfired@outlook.com
            //console.log(emailArr);
            var final_data = "";  
            var final_data2 = "";
            var winning_lead =[];
            var losing_lead =[];
            var winning_created_at =[];
            var losing_created_at =[];
            var winning_planmember_ref =[];
            var losing_planmember_ref =[];
            var winning_planemployer_ref =[];
            var losing_planemployer_ref =[];
            var winning_email =[];
            var losing_email =[];
            var winning_fname =[];
            var losing_fname =[];
            var winning_lname =[];
            var losing_lname =[];
            var final_count = emailArr.length;
             $.each(emailArr,function(i,arrEmail){  
                 console.log("arrEmail:"+arrEmail);
                $.ajax({
                    method: "GET",              
                    url: host + "/rest/v1/leads.json",                  
                    data: { 
                        filterType:"planEmployerRef",
                        filterValues: arrEmail,                    
                        fields: "id,firstname,lastname,email,planMemberRef,planEmployerRef,createdAt",
                        access_token: acc_token
                    },
                    dataType: "json",
                    success: function (data) {                    
                        console.log(data);  
                        $.each(data.result,function(i,e){                            
                             $.each(e,function(i,e){                            
                                final_data += i + ": " +e +", ";
                            });
                            final_data += "<br>";
                        });
                         $("#displayData").html(final_data);//.wrap("<table class='table table-bordered'></table>");
                        console.log("result");
                       console.log(data.result);
                       newArray = createDuplicateArrayObject(data.result);
                        console.log("newArraytest");
                       console.log(newArray);
                        var count = 0;
                        var count1 = 0;
                        var count2 = 0;
                        var count3 = 0;
                        var count4 = 0;
                        var count5 = 0;
                        var count6 = 0;
                        $.each(newArray,function(i,e){                            
                             $.each(e,function(i,e){                            
                                final_data2 += i + ": " +e +", ";
                                 if(i == "id") {
                                     (++count % 2) ? winning_lead.push(e) : losing_lead.push(e); 
                                 }
                                 
                                 if(i=="createdAt"){
                                     (++count1 % 2) ? winning_created_at.push(e) : losing_created_at.push(e); 
                                 }
                                 if(i=="planMemberRef"){
                                     (++count2 % 2) ? winning_planmember_ref.push(e) : losing_planmember_ref.push(e); 
                                 }
                                 if(i=="email"){
                                     (++count3 % 2) ? winning_email.push(e) : losing_email.push(e); 
                                 }
                                 if(i=="firstName"){
                                     (++count4 % 2) ? winning_fname.push(e) : losing_fname.push(e); 
                                 }
                                 if(i=="lastName"){
                                     (++count5 % 2) ? winning_lname.push(e) : losing_lname.push(e); 
                                 }
                                 if(i=="planEmployerRef"){
                                      (++count6 % 2) ? winning_planemployer_ref.push(e) : losing_planemployer_ref.push(e);
                                 }
                            });
                            final_data2 += "<br>";                            
                        });
                        if(newArray.length ) final_data2 = final_data2;
                      console.log("final_data2");console.log(winning_fname);
                        if(final_data2 == "") final_data2 = "No Duplicates Found";
                       // newArray.length  ?  final_data2 = final_data2 : final_data2 += "No Duplicates Found";
                        $("#displayMatchData").html(final_data2);
                       
                        if(i+1 == final_count){
//                            console.log(winning_lead);
//                            console.log(losing_lead);
                            addElementToMerge(winning_lead,losing_lead,winning_created_at,losing_created_at,winning_planmember_ref,losing_planmember_ref,winning_email,losing_email,winning_fname,losing_fname,winning_lname,losing_lname,winning_planemployer_ref,losing_planemployer_ref);
                            
                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr);
                    }
                });            
             }); 
             
        }//end function
        
        function addElementToMerge(winning,losing,winning_created_at,losing_created_at,winning_planmember_ref,losing_planmember_ref,winning_email,losing_email,winning_fname,losing_fname,winning_lname,losing_lname,winning_planemployer_ref,losing_planemployer_ref){
            var mergeField;
            for(i=winning.length-1;i>=0;i--){
                if(typeof(losing_planemployer_ref[i]) =="undefined")textcol="red";
                else  if(winning_planemployer_ref[i].toLowerCase()===losing_planemployer_ref[i].toLowerCase() &&                       
                        winning_created_at[i]>losing_created_at[i]){
                    textcol="green";
                }
                else{
                    textcol="red";
                }
                
                //Email
                if(typeof(losing_email[i]) =="undefined" || winning_email[i] == null || losing_email[i] == null)textcol_email="red";
                else  if(winning_email[i].toLowerCase()===losing_email[i].toLowerCase() &&                       
                        winning_created_at[i]>losing_created_at[i]){
                    textcol_email="green";
                }
                else{
                    textcol_email="red";
                }
                
               mergeField = '<div class="form-row"><div class="form-group col-md-6"><label for="winning_lead">Winning leadId:<br>'+winning_fname[i]+' '+winning_lname[i]+'<br><span style="color:'+textcol_email+'">'+winning_email[i]+'</span><br>['+winning_created_at[i]+']<br> [<span style="color:'+textcol+'">'+winning_planemployer_ref[i]+'</span>]<br>'+winning_planmember_ref[i]+'</label><input type="text" class="form-control winning-id" id="winning_lead'+i+'" placeholder="The id of the winning lead record" value="'+winning[i]+'"></div><div class="form-group col-md-6"><label for="losing_lead">Losing leadId:<br>'+losing_fname[i]+' '+losing_lname[i]+'<br><span style="color:'+textcol_email+'">'+losing_email[i]+'</span><br>['+losing_created_at[i]+']<br> [<span style="color:'+textcol+'">'+losing_planemployer_ref[i]+'</span>]<br>'+losing_planmember_ref[i]+'</label><input type="text" class="form-control losing-id" id="losing_lead'+i+'" placeholder="The id of the losing record" value="'+losing[i]+'"></div></div><button type="button" class="btn btn-primary merge-field">Merge</button><div class="form-group d-none"><label>Result</label><label class="form-control border-0 merge-result"></label></div>';
                $("legend.scheduler-border").after(mergeField);
            } 
             
        }
        
            
      
        function createDuplicateArrayObject(obj){
            var myObj = {};
            var newArray = [];
            $.each(obj,function(index,data){
                var planEmployerRef = data.planEmployerRef;
//                var compassID = parseInt(data.compassID);
               
//                console.log("planEmployerRef: "+planEmployerRef);
                if(typeof myObj[planEmployerRef] == 'undefined'){
                         myObj[planEmployerRef] =[];                  
                }
                myObj[planEmployerRef].push({
                    "id":data.id,
                    "firstName":data.firstName,
                    "lastName": data.lastName,
                    "email": data.email,
//                    "compassID":data.compassID,
                    "createdAt":data.createdAt,
                    "planMemberRef":data.planMemberRef,
                    "planEmployerRef":data.planEmployerRef
                });
                
            })
          console.log("myObj");
             console.log(myObj);
            newArray = addDuplicateArrayObject(myObj);
            return newArray;
        }
        
        function addDuplicateArrayObject(myObj){
            var dupes = [];
            var newArray = [];
              $.each(myObj,function(planEmployerRef,indexes){
//                  console.log(indexes);
                    if(indexes.length > 1) dupes.push(indexes);
              });
//              console.log("dupes[0][0].planEmployerRef"+dupes[0][0].planEmployerRef);
//            console.log("dupes[0][1].planEmployerRef"+dupes[0][1].planEmployerRef);
            console.log("length"+dupes.length)
        if (dupes.length){
            if(dupes[0][0].createdAt < dupes[0][1].createdAt){
                newArray = arrayReverseObj(dupes);
              } 
              else{
                 newArray = dupes[0];
              }
            console.log(dupes[0][0].createdAt < dupes[0][1].createdAt);
              console.log("newArray"+newArray.length);
        }
          
            
            return newArray;
        }
        
        function arrayReverseObj(obj) {
            var newArray = [];
            newArray = $(obj[0]).get().reverse();  
            return newArray; 
        }
        
        //https://855-bwk-979.mktorest.com/rest/v1/leads/1567687/merge.json?leadId=1714935&access_token=91f2473c-b589-4433-8102-b9fd5fa214f2:sn
        function mergeField(winning_id,losing_id,status){           
            var acc_token = $("#token").val();   
            $(status).html("<img src='img/apss-ajax-loader.gif'>");
//            var url = host + "/rest/v1/leads/" + winning_id + "/merge.json" ;
//            $.post( url, { leadId: losing_id, access_token: acc_token })
//            .done(function( data ) {
//              $("#mergeResult").text(data.success);
//            });
          $.ajax({
              headers : {
                    Accept : "text/json",
                    "Content-Type" : "application/json"
                },
                type: "POST",            
                url: host + "/rest/v1/leads/" + winning_id + "/merge.json?leadId="+losing_id+"&access_token="+acc_token,                  
//              data: { leadId: losing_id,access_token: acc_token},                                  
//                dataType: "json",
                success: function (result) {
                   var result = result.success;
                    console.log(result);
                    $(status).text(result);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    console.log(xhr);
                }
            });                
        }  
        