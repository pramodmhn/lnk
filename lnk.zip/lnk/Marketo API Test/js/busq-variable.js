 var host = "https://772-RAY-399.mktorest.com";//Busq-Endpoint
        var clientId = "c3bed0fe-fb40-4389-8919-f2e2f0e2a871";//
        var clientSecret = "OgdlJLVOC8n7QINC3lQlZZTtkF3gHJR6";//
        var token = "440927d7-39b0-4a41-a542-55c04c001f4b:sn";
       
        totalArray =[
          
            "5776631","37779900"

        ]