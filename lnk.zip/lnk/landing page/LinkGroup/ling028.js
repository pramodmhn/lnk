(function ($) {
   $(document).ready(function(){     
          
            /*Mobile dropdown menu effects */
            $("button.navbar-toggler").click(function(){
                 var expanded_icon = $(this).attr("aria-expanded");
                if(expanded_icon !== typeof undefined && expanded_icon !== "false"){                
                    $(this).find(".navbar-toggler-icon").css("background-image","url(https://mkt.linkgroup.com/rs/855-BWK-979/images/menu_icon.png)");
                }else{               
                    $(this).find(".navbar-toggler-icon").css("background-image","url(https://mkt.linkgroup.com/rs/855-BWK-979/images/close_menu_icon.png)"); 
//                    $(".navbar").addClass("px-0 pb-0");
//                    $(".navbar div").removeClass("container pl-3").addClass("container-fluid p-0 m-0").find(".nav-link").addClass("container");                
                } 
            });
             
            //submit form
             $("form#roundUpsForm").submit(function(){
                 $("textarea[name=messagetoCPM]").val($("textarea[name=contactMesage]").val());
                var myForm = MktoForms2.getForm("599");  
                myForm.submit(); 
                  
                  $("form#roundUpsForm").parent().addClass("d-table mb-3").css("height","240px").html('<div class="confirmation d-table-cell align-middle text-center"><img style="width:auto" src="https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif"></div>').addClass("bg-light"); 
                 
                 //Add an onSuccess handler
                  myForm.onSuccess(function(values, followUpUrl){
                   //get the form's jQuery element and hide it
                   myForm.getFormElem().hide();                 
                    $(".confirmation").html('<h4 class="brand-color px-3"><strong>Your message has been sent successfully.</strong></h4>');                   
                   //return false to prevent the submission handler from taking the lead to the follow up url.
                   return false;              
                });
                                  
                 //return false to prevent the submission handler from taking the lead to the follow up url.
                 return false;
             });
             
            /*reset the mobiel dropdown efffects */
//            $(window).resize(function(){  
//               var expanded_icon = $(this).attr("aria-expanded");
//                if($(window).width() > 974 && $(window).width() < 980){
//                     location.reload();
//                }           
//            });
        /*==============================================================
        fit videos
        ==============================================================*/
        $(".fit-videos").fitVids();
    });  

})(jQuery); // end