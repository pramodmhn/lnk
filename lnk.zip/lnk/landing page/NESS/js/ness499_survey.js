Survey
    .StylesManager
    .applyTheme("bootstrap");

var json = {
    "completedHtml": "<p class='completedHtml'><img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    "focusFirstQuestionAutomatic": false,
    "loadingHtml": "<p class='completedHtml'>Loading ...<img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    pages: [
        {
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel1",
                     "questions": [
                                {
                                   "type": "html",
                                   "name": "intro",
                                   "html": "<div class='text-left'>Please take a minute to leave us your candid feedback so we can continue to improve. Our team read each and every response. Don’t hold back, we want to know what you really think. Thank you!</div>"
                              },{
                                   "type": "html",
                                   "name": "intro Title1",
                                   "html": "<h4 class='sv_p_title'>How do you think we do with the following products and services?<h4>"
                              },{
                                "type": "rating",
                                "name": "customer service",
                                "title": "Over the phone customer service",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent",
                                "isRequired": false
                            }, {
                                "type": "rating",
                                "name": "communication",
                                "title": "Regular communications",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"
                              }
                        ],
//                    "title": "Please take a minute to leave us your candid feedback so we can continue to improve. Our team read each and every response. Don’t hold back, we want to know what you really think. Thank you!"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel1.2",
                     "questions": [
                         {
                                   "type": "html",
                                   "name": "intro Title1",
                                   "html": "<h4 class='sv_p_title'>How do you think we do with the following products and services?<h4>"
                              },{
                                "type": "rating",
                                "name": "workplace presence",
                                "title": "Workplace presence",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                "type": "rating",
                                "name": "investment performance",
                                "title": "Investment performance",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                "type": "rating",
                                "name": "fees",
                                "title": "Fees",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"
                              }
                        ],
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel1.3",
                     "questions": [
                         {
                                   "type": "html",
                                   "name": "intro Title1",
                                   "html": "<h4 class='sv_p_title'>How do you think we do with the following products and services?<h4>"
                              }, {
                                "type": "rating",
                                "name": "insurance Options",  
                                "title": "Insurance options",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                "type": "rating",
                                "name": "explaining language",
                                "title": "Explaining your super entitlements in plain language",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"
                              }
                        ],
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel2",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "understand super",  
                                "title": "How much do you understand about your super?",
                                "rateMax": 10,
                                "mininumRateDescription": "Not Much",
                                "maximumRateDescription": "A Lot"
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel3",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "financial performance", 
                                "title": "Financial performance",
                                 "rateValues": [
                                    {
                                     "value": "Less",
                                     "text": "Less"
                                    },
                                    {
                                     "value":"Same",
                                     "text": "Same"
                                    },
                                    {
                                     "value":"More",
                                     "text": "More"
                                    }
                                   ]
//                                "rateMax": 10,
//                                "mininumRateDescription": "Not Much",
//                                "maximumRateDescription": "A Lot"
                            }, {
                                "type": "rating",
                                "name": "product options", 
                                "title": "Product options",
                                 "rateValues": [
                                    {
                                     "value": "Less",
                                     "text": "Less"
                                    },
                                    {
                                     "value":"Same",
                                     "text": "Same"
                                    },
                                    {
                                     "value": "More",
                                     "text": "More"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "regular financial updates", 
                                "title": "Regular financial updates ",
                                 "rateValues": [
                                    {
                                     "value": "Less",
                                     "text": "Less"
                                    },
                                    {
                                     "value": "Same",
                                     "text": "Same"
                                    },
                                    {
                                     "value": "More",
                                     "text": "More"
                                    }
                                   ]
                            }, {
                                "type": "rating",
                                "name": "helpful tips",
                                "title": "Helpful tips on saving for the future",
                                 "rateValues": [
                                    {
                                     "value":"Less",
                                     "text": "Less"
                                    },
                                    {
                                     "value": "Same",
                                     "text": "Same"
                                    },
                                    {
                                     "value": "More",
                                     "text": "More"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "Other",
                                "title": "Other",
                               "commentText": " ",
                               "hasComment": true,
                                 "rateValues": [
                                    {
                                     "value": "Less",
                                     "text": "Less"
                                    },
                                    {
                                     "value": "Same",
                                     "text": "Same"
                                    },
                                    {
                                     "value": "More",
                                     "text": "More"
                                    }
                                   ]
                            }
                        ],
                        "questionTitleLocation": "left",
                        "title": "What would you be interested in hearing more about?"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel4",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "ness advise",
                                "title": "Would you like NESS to advise you if you had money in other funds or super lost to the tax office?",
                                "rateValues": [
                                    {
                                     "value": "Yes",
                                     "text": "Yes"
                                    },
                                    {
                                     "value": "Unsure",
                                     "text": "Unsure"
                                    },
                                    {
                                     "value": "No",
                                     "text": "No"
                                    }
                                   ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel5",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "loyal towards ness",
                                "title": "How loyal do you feel towards NESS?",
                                "rateMax": 10,
                                "mininumRateDescription": "Not Much",
                                "maximumRateDescription": "A Lot"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"
                              }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel6",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "enough insurance",
                                "title": "Do you think you have enough insurance to cover you for Death, Total and Permanent Disablement, and Income Protection?",
                                "rateValues": [
                                    {
                                     "value": "Not enough",
                                     "text": "Not enough"
                                    },
                                    {
                                     "value": "Enough",
                                     "text": "Enough"
                                    },
                                    {
                                     "value": "Too",
                                     "text": "Too"
                                    },
                                    {
                                     "value": "Unsure",
                                     "text": "Unsure"
                                    },
                                    {
                                     "value": "I don't know if I have any insurance",
                                     "text": "I don't know if I have any insurance"
                                    }
                                ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel7",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "recommend ness friend",
                                "title": "How likely are you to recommend NESS to a friend or colleague?",
                                "rateMax": 10,
                                "mininumRateDescription": "Not at all likely",
                                "maximumRateDescription": "Extremely likely"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"
                              }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        }, {
        questions: [
            {
               "type": "comment",
               "name": "comments",
               "title": "Do you have any other comments you would like to make?",
                "rows": 2
            }
        ]
          },{
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel8",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "contact for response",
                                "title": "Would you like someone to contact you about any of your responses?",
                                "rateValues": [
                                    {
                                     "value": "Yes",
                                     "text": "Yes"
                                    },
                                    {
                                     "value": "No",
                                     "text": "No"
                                    }
                                   ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        }
    ],
    "showProgressBar": "top",
    "showQuestionNumbers": "off",
    "requiredText": "*",
    "title": "HAVE YOUR SAY",
    "showCompletedPage": false
};

window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (result) {
//        document
//            .querySelector('#surveyResult')
//            .innerHTML = "result: " + JSON.stringify(result.data);
    var final_data = result.data;
    console.log(final_data);    
    $.each(final_data,function(i,e){
        assign_value(i,e);       
    });
    
    var myForm = MktoForms2.getForm("480");
    myForm.submit();
    });

$("#surveyElement").Survey({model: survey});

function assign_value(field_name,ans){
    var Q1 = "",Q2 = "",Q3 = "",Q4 = "",Q5 = "",Q6 = "",Q7 = "",Q8 = "",Q9 = "",Q10 = "";
    var Q11 = "",Q12 = "",Q13 = "",Q14 = "",Q15 = "",Q16 = "",Q17 = "",Q18 = "",Q19 = "",Q20 = "";
   switch(field_name){
        case "customer service":Q1 = ans; 
        $("input[name=q1]").val(Q1);
                break;
       case "communication":Q2 = ans; 
       $("input[name=q2]").val(Q2);
                break;
       case "workplace presence":Q3 = ans; 
       $("input[name=q3]").val(Q3);
                break;
       case "investment performance":Q4 = ans; 
       $("input[name=q4]").val(Q4);
                break;
       case "fees":Q5 = ans; 
       $("input[name=q5]").val(Q5);
                break;
       case "insurance Options":Q6 = ans;
           $("input[name=q6]").val(Q6);
                break;
       case "explaining language":Q7 = ans;
           $("input[name=q7]").val(Q7);
                break;
       case "understand super":Q8 = ans; 
           $("input[name=q8]").val(Q8);
                break;
       case "financial performance":Q9 = ans; 
           $("input[name=q9]").val(Q9);
                break;
       case "product options":Q10 = ans; 
           $("input[name=q10]").val(Q10);
                break;
       case "regular financial updates":Q11 = ans; 
            $("input[name=q11]").val(Q11);
                break;
       case "helpful tips":Q12 = ans; 
            $("input[name=q12]").val(Q12);
                break;
       case "Other":Q13 = ans; 
            $("input[name=q13]").val(Q13);
                break;
        case "Other-Comment":Q14 = ans;
            $("input[name=q14]").val(Q14);
                break;       
       case "ness advise":Q15 = ans; 
            $("input[name=q15]").val(Q15);
                break;
       case "loyal towards ness":Q16 = ans; 
            $("input[name=q16]").val(Q16);
                break;
       case "enough insurance":Q17 = ans; 
            $("input[name=q17]").val(Q17);
                break;
       case "recommend ness friend":Q18 = ans; 
            $("input[name=q18]").val(Q18);
                break;
       case "comments":Q19 = ans; 
            $("input[name=q19]").val(Q19);
                break;
       case "contact for response":Q20 = ans; 
            $("input[name=q20]").val(Q20);
                break;
//       case "fieldname":Q20 = ans; 
//                break;
        } 
}