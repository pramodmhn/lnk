Survey
    .StylesManager
    .applyTheme("bootstrap");

var json = {
    "completedHtml": "<p class='completedHtml'><img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    "focusFirstQuestionAutomatic": false,
    "loadingHtml": "<p class='completedHtml'>Loading ...<img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    pages: [
        {
            "name": "page1",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel1",
                     "questions": [
                                {
                                   "type": "html",
                                   "name": "intro",
                                   "html": "<div class='text-left'>Please take a minute to leave us your candid feedback so we can continue to improve. Our team read each and every response. Don’t hold back, we want to know what you really think. Thank you!</div>"
                              }, {
                                "type": "rating",
                                "name": "joining experience",
                                "title": "As a new member, how would you rate your joining experience?",
                                "rateMax": 10,
                                "mininumRateDescription": "Terrible",
                                "maximumRateDescription": "Excellent",
                                "isRequired": true
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"                                   
                              },  {
                                "type": "rating",
                                "name": "about your super",
                                "title": "How much do you understand about your super?",
                                "isRequired": true,
                                "rateMax": 10,
                                "mininumRateDescription": "Not Much",
                                "maximumRateDescription": "A Lot"                               
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"                                   
                              }
                        ],
                    },
                ]
        },{
            "name": "page2",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel2",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "financial performance", 
                                "title": "Financial performance",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
//                                "rateMax": 10,
//                                "mininumRateDescription": "Not Much",
//                                "maximumRateDescription": "A Lot"
                            }, {
                                "type": "rating",
                                "name": "customer service", 
                                "title": "Customer service",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "regular financial updates", 
                                "title": "Regular financial updates ",
                               "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                            }, {
                                "type": "rating",
                                "name": "helpful tips",
                                "title": "Helpful tips on saving for the future",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "other",
                                "title": "Other",
                               "commentText": " ",
                               "commentPlaceHolder": "comment",
                               "hasComment": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                            }
                        ],
                        "questionTitleLocation": "left",
                        "title": "Which of the following is the most important to you?"
                    },
                ]
        },{
            "name": "page3",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel3",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "ness advise",
                                "title": "Would you like NESS to advise you if you had super elsewhere, and help you roll it into your NESS account? (This can help you save on fees.)?",
                                "isRequired": true,
                                "rateValues": [
                                    {
                                     "value": "Yes",
                                     "text": "Yes"
                                    },
                                    {
                                     "value": "Unsure",
                                     "text": "Unsure"
                                    },
                                    {
                                     "value": "No",
                                     "text": "No"
                                    }
                                   ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            "name": "page4",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel4",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "enough insurance",
                                "title": "Do you think you have enough insurance to cover you for Death, Total and Permanent Disablement, and Income Protection?",
                                "isRequired": true,
                                "rateValues": [
                                    {
                                     "value": "Not enough",
                                     "text": "Not enough"
                                    },
                                    {
                                     "value": "Enough",
                                     "text": "Enough"
                                    },
                                    {
                                     "value": "Too much",
                                     "text": "Too much"
                                    },
                                    {
                                     "value": "Unsure",
                                     "text": "Unsure"
                                    }
                                ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            "name": "page5",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel5",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "recommend ness friend",
                                "title": "How likely are you to recommend NESS to a friend or colleague?",
                                "isRequired": true,
                                "rateMax": 10,
                                "mininumRateDescription": "Not at all likely",
                                "maximumRateDescription": "Extremely likely"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"                                   
                              }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        },{
            "name": "page6",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel6",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "method of contact",
                                "title": "What is usually your preferred method of contact?",
                                "isRequired": true,
                                "rateValues": [
                                    {
                                     "value": "Mail",
                                     "text": "Mail"
                                    },
                                    {
                                     "value": "Email",
                                     "text": "Email"
                                    },
                                    {
                                     "value": "SMS",
                                     "text": "SMS"
                                    }
                                   ]
                            },
                         
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        }, {
        "name": "page7",
        questions: [
            {
               "type": "comment",
               "name": "comments",
               "title": "Do you have any other comments you would like to make?",
                "isRequired": false,
                "rows": 2
            }
        ]
          },{
            "name": "page8",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel8",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "contact for response",
                                "title": "Would you like someone to contact you about any of your responses?",
                                "isRequired": true,
                                "rateValues": [
                                    {
                                     "value": "Yes",
                                     "text": "Yes"
                                    },
                                    {
                                     "value": "No",
                                     "text": "No"
                                    }
                                   ]
                            }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        }
    ],
    "showProgressBar": "top",
    "showQuestionNumbers": "off",
    "requiredText": "*",
    completeText: "Submit",
    "title": "HAVE YOUR SAY"
//    "showCompletedPage": false
};

window.survey = new Survey.Model(json);

survey
    .onComplete
    .add(function (result) {
//        document
//            .querySelector('#surveyResult')
//            .innerHTML = "result: " + JSON.stringify(result.data);
    var final_data = result.data;
    console.log(final_data);    
    $.each(final_data,function(i,e){
        assign_value(i,e);       
    });
    
    var myForm = MktoForms2.getForm("480");
    myForm.submit();
    });

$("#surveyElement").Survey({model: survey});

function assign_value(field_name,ans){
    var Q1 = "",Q2 = "",Q3 = "",Q4 = "",Q5 = "",Q6 = "",Q7 = "",Q8 = "",Q9 = "",Q10 = "";
    var Q11 = "",Q12 = "",Q13 = "",Q14 = "",Q15 = "",Q16 = "",Q17 = "",Q18 = "",Q19 = "",Q20 = "";
   switch(field_name){
        case "joining experience":Q1 = ans; 
        $("input[name=q1]").val(Q1);
                break;
       case "about your super":Q2 = ans; 
       $("input[name=q2]").val(Q2);
                break;
       case "financial performance":Q3 = ans; 
       $("input[name=q3]").val(Q3);
                break;
       case "customer service":Q4 = ans; 
       $("input[name=q4]").val(Q4);
                break;
       case "regular financial updates":Q5 = ans; 
       $("input[name=q5]").val(Q5);
                break;
       case "helpful tips":Q6 = ans;
           $("input[name=q6]").val(Q6);
                break;
       case "other":Q7 = ans;
           $("input[name=q7]").val(Q7);
                break;
       case "other-Comment":Q8 = ans; 
           $("input[name=q8]").val(Q8);
                break;
       case "ness advise":Q9 = ans; 
           $("input[name=q9]").val(Q9);
                break;
       case "enough insurance":Q10 = ans; 
           $("input[name=q10]").val(Q10);
                break;
       case "recommend ness friend":Q11 = ans; 
            $("input[name=q11]").val(Q11);
                break;
       case "method of contact":Q12 = ans; 
            $("input[name=q12]").val(Q12);
                break;
       case "comments":Q13 = ans; 
            $("input[name=q13]").val(Q13);
                break;
        case "contact for response":Q14 = ans;
            $("input[name=q14]").val(Q14);
                break;       
//       case "ness advise":Q15 = ans; 
//            $("input[name=q15]").val(Q15);
//                break;
//       case "loyal towards ness":Q16 = ans; 
//            $("input[name=q16]").val(Q16);
//                break;
//       case "enough insurance":Q17 = ans; 
//            $("input[name=q17]").val(Q17);
//                break;
//       case "recommend ness friend":Q18 = ans; 
//            $("input[name=q18]").val(Q18);
//                break;
//       case "comments":Q19 = ans; 
//            $("input[name=q19]").val(Q19);
//                break;
//       case "contact for response":Q20 = ans; 
//            $("input[name=q20]").val(Q20);
//                break;
//       case "fieldname":Q20 = ans; 
//                break;
        } 
}