Survey
    .StylesManager
    .applyTheme("bootstrap");

var json = {
    "completedHtml": "<p class='completedHtml'><img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    "focusFirstQuestionAutomatic": false,
    "loadingHtml": "<p class='completedHtml'>Loading ...<img class='img-fluid' src='https://mkt.linkgroup.com/rs/855-BWK-979/images/ajax-loader.gif'></p>",
    pages: [
        {
            "name": "page1",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel1",
                     "questions": [
                         {
                                   "type": "html",
                                   "name": "intro",
                                   "html": "<div class='text-left'>Please take a minute to leave us your candid feedback so we can continue to improve. Our team read each and every response. Don’t hold back, we want to know what you really think. Thank you!</div>"
                              }, {
                                   "type": "html",
                                   "name": "title",
                                   "html": "<h3 class='sv_p_title text-left'>Which is most important to you when choosing a default fund for your employees?</h3>"
                              },{
                                "type": "rating",
                                "name": "ease of setup", 
                                "title": "Ease of setup",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
//                                "rateMax": 10,
//                                "mininumRateDescription": "Not Much",
//                                "maximumRateDescription": "A Lot"
                            }, {
                                "type": "rating",
                                "name": "ease of making contributions", 
                                "title": "Ease of making contributions",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "access to information", 
                                "title": "Access to information",
                               "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                            }, {
                                "type": "rating",
                                "name": "financial advice",
                                "title": "Ability to provide financial advice",
                                "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "fund with",
                                "title": "Which fund I am personally with",
                               "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "onsite representative",
                                "title": "Onsite visits by a representative",
                               "isRequired": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                           }, {
                                "type": "rating",
                                "name": "other",
                                "title": "Other",
                               "commentText": " ",                               
                               "hasComment": true,
                                 "rateValues": [
                                    {
                                     "value": "Low",
                                     "text": "Low"
                                    },
                                    {
                                     "value":"Medium",
                                     "text": "Medium"
                                    },
                                    {
                                     "value":"High",
                                     "text": "High"
                                    }
                                   ]
                            }
                        ],  
                        "questionTitleLocation": "left",
//                        "title": "Which is most important to you when choosing a default fund for your employees?"
                    },
                ]
        },{
            "name": "page2",
            elements: [  
                    {
                     "type": "panel",
                     "name": "panel2",
                     "questions": [
                            {
                                "type": "rating",
                                "name": "loyal towards ness",
                                "title": "How loyal do you feel towards NESS?",
                                "isRequired": true,
                                "rateMax": 10,
                                "mininumRateDescription": "Not Much",
                                "maximumRateDescription": "A Lot"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"                                   
                              },{
                                "type": "rating",
                                "name": "recommend ness friend",
                                "title": "Recommend NESS to a friend or colleague?",
                                  "isRequired": true,
                                "rateMax": 10,
                                "mininumRateDescription": "Not at all likely",
                                "maximumRateDescription": "Extremely likely"
                            }, {
                                   "type": "html",
                                   "name": "slider",
                                   "html": "<div class='show-slider'></div>"                                   
                              }
                        ],
//                    "title": "Q2. How do you think we do witht the following products and services?"
                    },
                ]
        }, {
        "name": "page3",
        questions: [
            {
               "type": "comment",
               "name": "comments",
               "title": "Do you have any other comments you would like to make?",
                "isRequired": false,
                "rows": 2
            }
        ]
          }
    ],
    "showProgressBar": "top",
    "showQuestionNumbers": "off",
    "requiredText": "*",
    completeText: "Submit",
    "title": "HAVE YOUR SAY"
//    "goNextPageAutomatic": true
//    "showCompletedPage": false
};

window.survey = new Survey.Model(json);
//console.log(survey.completeLastPage());
survey
    .onComplete
    .add(function (result) {
//        document
//            .querySelector('#surveyResult')
//            .innerHTML = "result: " + JSON.stringify(result.data);
    var final_data = result.data;
    console.log(final_data);    
    $.each(final_data,function(i,e){
        assign_value(i,e);       
    });
    
    var myForm = MktoForms2.getForm("480");
    myForm.submit();
    });

$("#surveyElement").Survey({model: survey});

function assign_value(field_name,ans){
    var Q1 = "",Q2 = "",Q3 = "",Q4 = "",Q5 = "",Q6 = "",Q7 = "",Q8 = "",Q9 = "",Q10 = "";
    var Q11 = "",Q12 = "",Q13 = "",Q14 = "",Q15 = "",Q16 = "",Q17 = "",Q18 = "",Q19 = "",Q20 = "";
   switch(field_name){
        case "ease of setup":Q1 = ans; 
        $("input[name=q1]").val(Q1);
                break;
       case "ease of making contributions":Q2 = ans; 
       $("input[name=q2]").val(Q2);
                break;
       case "access to information":Q3 = ans; 
       $("input[name=q3]").val(Q3);
                break;
       case "financial advice":Q4 = ans; 
       $("input[name=q4]").val(Q4);
                break;
       case "fund with":Q5 = ans; 
       $("input[name=q5]").val(Q5);
                break;
       case "onsite representative":Q6 = ans;
           $("input[name=q6]").val(Q6);
                break;
       case "other":Q7 = ans;
           $("input[name=q7]").val(Q7);
                break;
       case "other-Comment":Q8 = ans; 
           $("input[name=q8]").val(Q8);
                break;
       case "loyal towards ness":Q9 = ans; 
           $("input[name=q9]").val(Q9);
                break;
       case "recommend ness friend":Q10 = ans; 
           $("input[name=q10]").val(Q10);
                break;
       case "comments":Q11 = ans; 
            $("input[name=q11]").val(Q11);
                break;
//       case "method of contact":Q12 = ans; 
//            $("input[name=q12]").val(Q12);
//                break;
//       case "comments":Q13 = ans; 
//            $("input[name=q13]").val(Q13);
//                break;
//        case "contact for response":Q14 = ans;
//            $("input[name=q14]").val(Q14);
//                break;       
//       case "ness advise":Q15 = ans; 
//            $("input[name=q15]").val(Q15);
//                break;
//       case "loyal towards ness":Q16 = ans; 
//            $("input[name=q16]").val(Q16);
//                break;
//       case "enough insurance":Q17 = ans; 
//            $("input[name=q17]").val(Q17);
//                break;
//       case "recommend ness friend":Q18 = ans; 
//            $("input[name=q18]").val(Q18);
//                break;
//       case "comments":Q19 = ans; 
//            $("input[name=q19]").val(Q19);
//                break;
//       case "contact for response":Q20 = ans; 
//            $("input[name=q20]").val(Q20);
//                break;
//       case "fieldname":Q20 = ans; 
//                break;
        } 
}